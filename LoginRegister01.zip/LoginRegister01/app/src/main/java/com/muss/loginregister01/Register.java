package com.muss.loginregister01;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.ActionCodeSettings;
import com.google.firebase.auth.FirebaseAuth;


public class Register extends AppCompatActivity {
    EditText fullNameET, emailET, mobileET, passwordET;
    TextView tvNameError, tvEmailError, tvMobileError, tvPasswordError;
    CardView card1, card2, card3, card4, card5;
    Button signUpBtn;
    CheckBox checkBox;
    String email;


    private boolean passwordShowing = false;
    private  boolean isAtLeast8Characters = false, hasAtLeastUpperCase = false, hasAtLeastLowerCase = false, hasAtLeastNumber = false, hasAtLeastSymbol = false;

    private final boolean checkEmptyField = false;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

         fullNameET = findViewById(R.id.fullNameET);
         emailET = findViewById(R.id.emailET);
         mobileET = findViewById(R.id.mobileET);

         passwordET = findViewById(R.id.passwordET);


        tvNameError = findViewById(R.id.tvNameError);
        tvEmailError = findViewById(R.id.tvEmailError);
        tvMobileError = findViewById(R.id.tvMobileError);
        tvPasswordError = findViewById(R.id.tvPasswordError);

        card1 = findViewById(R.id.card1);
        card2 = findViewById(R.id.card2);
        card3 = findViewById(R.id.card3);
        card4 = findViewById(R.id.card4);
        card5 = findViewById(R.id.card5);

        checkBox = findViewById(R.id.checkBox);





        final ImageView passwordIcon = findViewById( R.id.passwordIcon);


         signUpBtn = findViewById(R.id.signUpBtn);
        final TextView signInBtn = findViewById( R.id.signInBtn);

        ActionCodeSettings actionCodeSettings =
                ActionCodeSettings.newBuilder()
                        // URL you want to redirect back to. The domain (www.example.com) for this
                        // URL must be whitelisted in the Firebase Console.
                        .setUrl("https://www.example.com/finishSignUp?cartId=1234")
                        // This must be true
                        .setHandleCodeInApp(true)
                        .setIOSBundleId("com.example.ios")
                        .setAndroidPackageName(
                                "com.example.android",
                                true, /* installIfNotAvailable */
                                "12"    /* minimumVersion */)
                        .build();

        passwordET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String password = passwordET.getEditableText().toString().trim();

                if (password.isEmpty()) {
                    passwordET.setError("Field can not be empty.");

                }
            }
        });

        passwordIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // checking if password is showing or not
                if(passwordShowing){
                    passwordShowing = false;

                    passwordET.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    passwordIcon.setImageResource(R.drawable.show_password);
                }
                else{
                    passwordShowing = true;

                    passwordET.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    passwordIcon.setImageResource(R.drawable.password_hide);
                }

                // move the cursor to end of text
                passwordET.setSelection(passwordET.length());

            }
        });

        passwordET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


        signUpBtn.setOnClickListener(new View.OnClickListener() {

            @SuppressLint("ResourceType")
            public void onClick(View v) {

                final String getMobileTxt = mobileET.getText().toString();
                final String getEmailTxt  = emailET.getText().toString();
                final String getPasswordTxt = passwordET.getText().toString();


                if(fullNameET.length() > 0 && emailET.length() > 0 && mobileET.length() > 0 && passwordET.length() > 0){
                    Toast.makeText(Register.this, "ok", Toast.LENGTH_SHORT).show();
                }else {
                    if (fullNameET.length() == 0) {
                        tvNameError.setVisibility(View.VISIBLE);
                    }
                    if (emailET.length() == 0) {
                        tvEmailError.setVisibility(View.VISIBLE);
                    }
                    if (mobileET.length() == 0) {
                        tvMobileError.setVisibility(View.VISIBLE);
                    }
                    if (passwordET.length() == 0) {
                        tvPasswordError.setVisibility(View.VISIBLE);
                    }


                        if (fullNameET.length() > 0 && tvNameError.getVisibility() == View.VISIBLE) {
                            tvNameError.setVisibility(View.GONE);
                        }
                        if (emailET.length() > 0 && tvEmailError.getVisibility() == View.VISIBLE) {
                            tvEmailError.setVisibility(View.GONE);
                        }
                        if (passwordET.length() > 0 && tvPasswordError.getVisibility() == View.VISIBLE) {
                            tvPasswordError.setVisibility(View.GONE);
                        }


                      String email;

                        String fullName = fullNameET.getText().toString();
                         email = emailET.getText().toString();
                        String password = passwordET.getText().toString();

                        checkEmptyField(fullName, email, password);

                        //for uppercase
                        if (password.matches("(.*[A-Z].*)")) {
                            hasAtLeastUpperCase = true;
                            card1.setCardBackgroundColor(Color.parseColor(getString(R.color.colorAccent)));
                        } else {
                            hasAtLeastUpperCase = false;
                            card1.setCardBackgroundColor(Color.parseColor(getString(R.color.colorDefault)));

                        }
                        // for lowercase
                        if (password.matches("(.*[a-z].*)")) {
                            hasAtLeastLowerCase = true;
                            card2.setCardBackgroundColor(Color.parseColor(getString(R.color.colorAccent)));
                        } else {
                            hasAtLeastLowerCase = false;
                            card2.setCardBackgroundColor(Color.parseColor(getString(R.color.colorDefault)));

                        }
                        //for number
                        if (password.matches("(.*[0-9].*)")) {
                            hasAtLeastNumber = true;
                            card3.setCardBackgroundColor(Color.parseColor(getString(R.color.colorAccent)));
                        } else {
                            hasAtLeastNumber = false;
                            card3.setCardBackgroundColor(Color.parseColor(getString(R.color.colorDefault)));

                        }
                        //for symbol
                        if (password.matches("^(?=.*[_.()]).*$")) {
                            hasAtLeastSymbol = true;
                            card4.setCardBackgroundColor(Color.parseColor(getString(R.color.colorAccent)));
                        } else {
                            hasAtLeastSymbol = false;
                            card4.setCardBackgroundColor(Color.parseColor(getString(R.color.colorDefault)));

                        }
                        //for 8 characters
                        if (password.length() >= 8) {
                            isAtLeast8Characters = true;
                            card5.setCardBackgroundColor(Color.parseColor(getString(R.color.colorAccent)));
                        } else {
                            isAtLeast8Characters = false;
                            card5.setCardBackgroundColor(Color.parseColor(getString(R.color.colorDefault)));

                        }

                        checkAllData(password);


                    //if all fields are in order the btn color will change
                        boolean isSignUpClickable;
                        if (hasAtLeastUpperCase && hasAtLeastLowerCase && hasAtLeastNumber && hasAtLeastSymbol && isAtLeast8Characters && emailET.length() > 0) {
                            isSignUpClickable = true;
                            signUpBtn.setBackgroundColor(Color.parseColor(getString(R.color.colorAccent)));
                        } else {
                            isSignUpClickable = false;
                            signUpBtn.setBackgroundColor(Color.parseColor(getString(R.color.colorDefault)));
                        }
                    }

                        fullNameET.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                passwordCheck();

                            }

                            private void passwordCheck() {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                            }
                        });
                        emailET.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                passwordCheck();

                            }

                            private void passwordCheck() {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                            }
                        });
                        mobileET.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                passwordCheck();

                            }

                            private void passwordCheck() {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                            }
                        });
                        passwordET.addTextChangedListener(new TextWatcher() {
                            @Override
                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                            }

                            @Override
                            public void onTextChanged(CharSequence s, int start, int before, int count) {
                                passwordCheck();

                            }

                            private void passwordCheck() {
                            }

                            @Override
                            public void afterTextChanged(Editable s) {

                            }
                        });



                final FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();

                FirebaseAuth mAuth = FirebaseAuth.getInstance();




                FirebaseAuth auth = FirebaseAuth.getInstance();
                auth.sendSignInLinkToEmail(getEmailTxt, actionCodeSettings)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Log.d(TAG, "Email sent.");
                                }
                            }
                        });

                firebaseAuth.createUserWithEmailAndPassword(getEmailTxt,getPasswordTxt).addOnCompleteListener((task ->{
                    if(task.isSuccessful()) {

                        firebaseAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> sendSignInLinkToEmail) {
                                if(task.isSuccessful()) {
                                    Toast.makeText(Register.this,"Registration successful, Please Verify your Email", Toast.LENGTH_SHORT).show();
                                    emailET.getText().toString();
                                    passwordET.getText().toString();

                                    // opening OTP get Activity along with mobile and email
                                    Intent intent = new Intent(Register.this, sendOTPActivity.class);

                                    intent.putExtra( "mobile", getMobileTxt);
                                    intent.putExtra("email", getEmailTxt);

                                    startActivity(intent);

                                }
                            }
                        });


                    }else{
                        Toast.makeText(Register.this,task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                ));



            }

            private void checkAllData(String passwordET) {
            }

            private void checkEmptyField(String fullName, String email, String password) {
            }
        });

        signInBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Register.this, Login.class));
                finish();
            }
        });
    }
}